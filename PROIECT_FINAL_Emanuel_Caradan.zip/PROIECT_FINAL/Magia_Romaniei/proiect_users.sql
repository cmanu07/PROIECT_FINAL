-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2022 at 03:55 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdev`
--

-- --------------------------------------------------------

--
-- Table structure for table `proiect_users`
--

CREATE TABLE `proiect_users` (
  `ID` int(11) NOT NULL,
  `Nume` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `UserName` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proiect_users`
--

INSERT INTO `proiect_users` (`ID`, `Nume`, `UserName`, `Email`, `Password`) VALUES
(1, 'emanuel', 'manu07', 'cemanuel86@gmail.com', '$2a$12$gCm4khjZgrGb33sjOZzVt.v5PPoZAp29H6XnyvWTbfSrTBVvEH0qa'),
(2, '', 'asdasd3', 'cemanuel86@gmail.com', '$2y$10$4YXq4ZpSwsS7VuKe3UmRJu2J1aHoq8Z4zaAVBX8RS91zMBeP/MfSe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `proiect_users`
--
ALTER TABLE `proiect_users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `UserName` (`UserName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `proiect_users`
--
ALTER TABLE `proiect_users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
