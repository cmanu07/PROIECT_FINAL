<?php

class SignUpController extends AppController
{
    public function __construct() {
        $this -> init();
    }

    public function init() {
        $user = $_POST['nameSUp'];
        $userN = $_POST['userNameSUp'];
        $userE = $_POST['emailSUp'];
        $userP = $_POST['parolaSUp'];

        $user = new UserModel;

        if ($user -> signUpUser($user, $userN, $userE, $userP)) {
            session_start();
            $_SESSION['user'] = $userN;
            $data['mainContent'] = $_SESSION['user'];
            echo $this->render(APP_PATH.VIEWS.'layoutAuth.html',$data);
        }
    }
}