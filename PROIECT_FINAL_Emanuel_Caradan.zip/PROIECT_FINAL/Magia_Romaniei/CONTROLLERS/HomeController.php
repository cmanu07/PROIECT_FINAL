<?php

class HomeController extends AppController
{
    public function __construct() {
        $this -> init();
    }

    public function init() {
        $data['title'] = 'Magia Romaniei';
        $data['mainContent'] = $this -> render(APP_PATH . VIEWS . 'homeView.html');
        $data['mainContent'] .= $this -> render(APP_PATH . VIEWS . 'despreView.html');
        echo $this -> render(APP_PATH . VIEWS . 'layout.html', $data);
    }
}