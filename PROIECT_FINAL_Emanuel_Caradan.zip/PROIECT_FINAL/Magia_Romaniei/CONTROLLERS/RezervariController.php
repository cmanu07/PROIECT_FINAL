<?php

class RezervariController extends AppController
{
    public function __construct() {
        $this -> init();
    }

    public function init() {
        $data['title'] = 'Rezervări';
        $data['mainContent'] = $this -> render(APP_PATH . VIEWS . 'rezervariView.html');
        $data['mainContent'] .= $this -> render(APP_PATH . VIEWS . 'despreView.html');
        echo $this -> render(APP_PATH . VIEWS . 'layout.html', $data);
    }
}