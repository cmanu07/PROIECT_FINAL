<?php

// configurarea site-ului
include_once 'config.php';

// fisierul de control
new AppController;